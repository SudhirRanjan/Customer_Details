package com.sudhir.App.Repository;

import org.springframework.data.repository.CrudRepository;

import com.sudhir.App.Entity.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

}
