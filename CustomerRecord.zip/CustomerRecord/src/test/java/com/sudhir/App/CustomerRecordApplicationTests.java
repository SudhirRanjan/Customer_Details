package com.sudhir.App;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sudhir.App.Entity.Customer;
import com.sudhir.App.Repository.CustomerRepo;

@SpringBootTest
class CustomerRecordApplicationTests {
	@Autowired
	CustomerRepo repo;
	
     @Test
	public void customerSavingTesting()
	{
    	 Customer cust=new Customer();
    	 cust.setName("Irshad");
    	 cust.setAddress("Miss.Ananya ");
    	 cust.setPhoneNo("9392959823");
    	 repo.save(cust);
    	 
	}
     @Test
     public Customer findByid()
     {
    	return repo.findById(1).get();
    	 
     }

}
